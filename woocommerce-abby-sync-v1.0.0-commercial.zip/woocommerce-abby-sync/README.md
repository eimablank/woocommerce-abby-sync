# WooCommerce Abby Sync

Lightweight WooCommerce integration for Abby accounting software.

Automatically synchronize WooCommerce orders with Abby draft invoices while preserving WooCommerce as the main commercial source of truth.

## Features

- Automatic Abby draft invoice creation
- WooCommerce customer synchronization
- French VAT support
- Multiple VAT rates support
- Product line synchronization
- SKU synchronization
- Shipping cost synchronization
- Duplicate prevention
- Lightweight architecture
- No Zapier or Make dependency
- WooCommerce HPOS compatibility
- Admin settings page
- Abby API key test button

## Designed for

- Artists
- Designers
- Freelancers
- French businesses
- WooCommerce stores
- Abby accounting users

## Workflow

WooCommerce → WooCommerce VAT → Order → WooCommerce Abby Sync → Abby Draft Invoice

WooCommerce remains the primary source for products, taxes, pricing, checkout, and customer management.

Abby handles invoicing, accounting, and French compliance.

## Requirements

- WordPress
- WooCommerce
- Abby account
- Abby API key

## Installation

1. Upload the plugin ZIP.
2. Activate the plugin.
3. Go to WooCommerce → Abby Sync.
4. Open the Réglages tab.
5. Enter your Abby API key.
6. Click Tester la clé Abby.
7. Configure WooCommerce taxes.
8. Start synchronizing WooCommerce orders.

## VAT

VAT is calculated directly from WooCommerce orders and transmitted to Abby.

Supported examples:

| VAT Type | Abby Code |
|---|---|
| 20% | FR_2000 |
| 10% | FR_1000 |
| 8.5% | FR_850 |
| 5.5% | FR_550 |
| 2.1% | FR_210 |
| 0% | FR_00HT |

## Philosophy

This plugin intentionally stays lightweight.

WooCommerce handles commerce. Abby handles accounting.

The plugin acts only as a synchronization bridge.

## License

Copyright © Sandrine GERMAIN

All rights reserved.

## Support

https://sandrinegermain.com
