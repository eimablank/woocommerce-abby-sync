<?php
/**
 * Plugin Name: SG Abby Sync for WooCommerce
 * Plugin URI: https://sandrinegermain.com
 * Description: Synchronise les commandes WooCommerce avec Abby : contacts, factures brouillon, lignes produits, SKU et TVA WooCommerce transmise à Abby.
 * Version: 1.0.0
 * Author: Sandrine GERMAIN
 * Author URI: https://sandrinegermain.com
 * License: Proprietary
 * Text Domain: sg-abby-sync
 */

if (!defined('ABSPATH')) {
    exit;
}

define('SG_ABBY_SYNC_VERSION', '1.0.0');
define('SG_ABBY_SYNC_API_BASE', 'https://api.app-abby.com');

/**
 * WooCommerce HPOS compatibility.
 */
add_action('before_woocommerce_init', function () {
    if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            'custom_order_tables',
            __FILE__,
            true
        );
    }
});

/**
 * Admin menu.
 */
add_action('admin_menu', 'sg_abby_sync_admin_menu');

function sg_abby_sync_admin_menu() {
    add_submenu_page(
        'woocommerce',
        'SG Abby Sync',
        'Abby Sync',
        'manage_woocommerce',
        'sg-abby-sync',
        'sg_abby_sync_render_admin_page'
    );
}

/**
 * Settings link in plugin list.
 */
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'sg_abby_sync_plugin_action_links');

function sg_abby_sync_plugin_action_links($links) {
    $settings_link = '<a href="' . esc_url(admin_url('admin.php?page=sg-abby-sync&tab=settings')) . '">Réglages</a>';
    array_unshift($links, $settings_link);
    return $links;
}

/**
 * Register settings.
 */
add_action('admin_init', 'sg_abby_sync_register_settings');

function sg_abby_sync_register_settings() {
    register_setting(
        'sg_abby_sync_settings_group',
        'sg_abby_sync_api_key',
        [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ]
    );
}

/**
 * Admin page tabs.
 */
function sg_abby_sync_render_admin_page() {
    if (!current_user_can('manage_woocommerce')) {
        return;
    }

    $active_tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'home';

    ?>
    <div class="wrap">
        <h1>SG Abby Sync for WooCommerce</h1>

        <h2 class="nav-tab-wrapper">
            <a href="<?php echo esc_url(admin_url('admin.php?page=sg-abby-sync&tab=home')); ?>"
               class="nav-tab <?php echo $active_tab === 'home' ? 'nav-tab-active' : ''; ?>">
                Accueil
            </a>

            <a href="<?php echo esc_url(admin_url('admin.php?page=sg-abby-sync&tab=settings')); ?>"
               class="nav-tab <?php echo $active_tab === 'settings' ? 'nav-tab-active' : ''; ?>">
                Réglages
            </a>
        </h2>

        <?php
        if ($active_tab === 'settings') {
            sg_abby_sync_render_settings_tab();
        } else {
            sg_abby_sync_render_home_tab();
        }
        ?>
    </div>
    <?php
}

/**
 * Home tab.
 */
function sg_abby_sync_render_home_tab() {
    ?>
    <div style="max-width: 920px; margin-top: 20px;">

        <h2>Synchroniser WooCommerce avec Abby simplement</h2>

        <p>
            SG Abby Sync for WooCommerce crée automatiquement des factures brouillon Abby à partir de vos commandes WooCommerce.
            Le plugin conserve WooCommerce comme source de vérité commerciale : produits, prix, clients, TVA et paiement.
            Abby reçoit ensuite les informations nécessaires à la facturation et à la comptabilité.
        </p>

        <h3>Pourquoi ce plugin ?</h3>

        <ul style="list-style: disc; padding-left: 22px;">
            <li>Éviter les scénarios Make ou Zapier fragiles.</li>
            <li>Créer des factures brouillon Abby directement depuis WooCommerce.</li>
            <li>Transmettre les lignes produits, les SKU, les quantités et la TVA calculée par WooCommerce.</li>
            <li>Éviter les doublons de clients et de factures.</li>
            <li>Préparer une organisation plus cohérente pour la comptabilité et la facturation électronique.</li>
        </ul>

        <h3>Workflow</h3>

        <p>
            <code>WooCommerce → TVA WooCommerce → Commande → SG Abby Sync → Facture brouillon Abby</code>
        </p>

        <h3>Créer une clé API Abby</h3>

        <ol>
            <li>Connectez-vous à votre compte Abby.</li>
            <li>Ouvrez les paramètres de votre compte Abby.</li>
            <li>Allez dans la section API ou Développeur.</li>
            <li>Créez une nouvelle clé API.</li>
            <li>Copiez la clé.</li>
            <li>Revenez dans WordPress → WooCommerce → Abby Sync → Réglages.</li>
            <li>Collez la clé API puis enregistrez.</li>
            <li>Utilisez le bouton “Tester la clé Abby”.</li>
        </ol>

        <h3>Configuration recommandée</h3>

        <ul style="list-style: disc; padding-left: 22px;">
            <li>Configurez d’abord vos taxes dans WooCommerce.</li>
            <li>Attribuez la bonne classe TVA à chaque produit ou service.</li>
            <li>Gardez Abby en mode facture brouillon pour pouvoir vérifier avant validation.</li>
            <li>N’utilisez pas plusieurs moteurs TVA concurrents si WooCommerce est votre source de vérité.</li>
        </ul>

        <h3>Mise en conformité comptable</h3>

        <p>
            Ce plugin ne remplace pas un conseil comptable. Il aide à fiabiliser la transmission entre WooCommerce et Abby :
            WooCommerce calcule la TVA, Abby reçoit les éléments de facturation, et vous gardez la possibilité de contrôler
            les brouillons avant émission définitive.
        </p>

    </div>
    <?php
}

/**
 * Settings tab.
 */
function sg_abby_sync_render_settings_tab() {
    $api_key = get_option('sg_abby_sync_api_key', '');
    $test_result = '';

    if (
        isset($_POST['sg_abby_sync_test_key']) &&
        check_admin_referer('sg_abby_sync_test_key_action', 'sg_abby_sync_test_key_nonce')
    ) {
        $test_result = sg_abby_sync_test_api_key();
    }

    ?>
    <div style="max-width: 920px; margin-top: 20px;">

        <h2>Réglages Abby</h2>

        <form method="post" action="options.php">
            <?php settings_fields('sg_abby_sync_settings_group'); ?>

            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row">
                        <label for="sg_abby_sync_api_key">Clé API Abby</label>
                    </th>
                    <td>
                        <input
                            type="password"
                            id="sg_abby_sync_api_key"
                            name="sg_abby_sync_api_key"
                            value="<?php echo esc_attr($api_key); ?>"
                            class="regular-text"
                            autocomplete="off"
                        />
                        <p class="description">
                            La clé est stockée dans WordPress et utilisée uniquement pour communiquer avec l’API Abby.
                        </p>
                    </td>
                </tr>
            </table>

            <?php submit_button('Enregistrer la clé'); ?>
        </form>

        <hr />

        <h2>Tester la clé Abby</h2>

        <form method="post">
            <?php wp_nonce_field('sg_abby_sync_test_key_action', 'sg_abby_sync_test_key_nonce'); ?>
            <input type="hidden" name="sg_abby_sync_test_key" value="1" />
            <?php submit_button('Tester la clé Abby', 'secondary'); ?>
        </form>

        <?php if (!empty($test_result)) : ?>
            <div style="margin-top: 15px;">
                <?php echo wp_kses_post($test_result); ?>
            </div>
        <?php endif; ?>

        <hr />

        <h2>Statut</h2>

        <?php if (!empty($api_key)) : ?>
            <p style="color: green;"><strong>Clé API Abby enregistrée.</strong></p>
        <?php else : ?>
            <p style="color: #b32d2e;"><strong>Aucune clé API Abby enregistrée.</strong></p>
        <?php endif; ?>

    </div>
    <?php
}

/**
 * API key test.
 */
function sg_abby_sync_test_api_key() {
    try {
        $response = sg_abby_sync_request('GET', '/contacts?page=1&limit=1');

        return '<div class="notice notice-success inline"><p><strong>Connexion Abby réussie.</strong> La clé API semble valide.</p></div>';

    } catch (Exception $e) {
        return '<div class="notice notice-error inline"><p><strong>Échec de connexion Abby :</strong> ' . esc_html($e->getMessage()) . '</p></div>';
    }
}

/**
 * WooCommerce order hooks.
 */
add_action('woocommerce_order_status_processing', 'sg_abby_sync_order', 20, 1);
add_action('woocommerce_order_status_completed', 'sg_abby_sync_order', 20, 1);
add_action('woocommerce_order_status_on-hold', 'sg_abby_sync_order', 20, 1);

/**
 * Main order synchronization.
 */
function sg_abby_sync_order($order_id) {
    if (!function_exists('wc_get_order')) {
        return;
    }

    $order = wc_get_order($order_id);

    if (!$order) {
        return;
    }

    if ($order->get_meta('_abby_invoice_id') && $order->get_meta('_abby_lines_ok')) {
        return;
    }

    if ($order->get_meta('_abby_sync_in_progress')) {
        return;
    }

    $api_key = sg_abby_sync_get_api_key();

    if (empty($api_key)) {
        $order->add_order_note('Erreur Abby : clé API Abby manquante. Configurez WooCommerce → Abby Sync → Réglages.');
        return;
    }

    $order->update_meta_data('_abby_sync_in_progress', 1);
    $order->save();

    try {
        if (!$order->get_billing_email()) {
            throw new Exception('Email client manquant.');
        }

        $order->add_order_note('SG Abby Sync : synchronisation démarrée.');

        $contact_id = sg_abby_sync_find_or_create_contact($order);

        if (!$contact_id) {
            throw new Exception('Contact Abby introuvable ou non créé.');
        }

        $invoice_id = $order->get_meta('_abby_invoice_id');

        if (!$invoice_id) {
            $invoice = sg_abby_sync_create_draft_invoice($contact_id);

            if (empty($invoice['id'])) {
                throw new Exception('Facture Abby créée sans ID retourné : ' . wp_json_encode($invoice));
            }

            $invoice_id = $invoice['id'];
            $order->update_meta_data('_abby_invoice_id', $invoice_id);
            $order->save();
        }

        $response_lines = sg_abby_sync_update_invoice_lines($invoice_id, $order);

        $order->update_meta_data('_abby_lines_ok', 1);
        $order->delete_meta_data('_abby_sync_in_progress');
        $order->save();

        $order->add_order_note('Abby : facture brouillon synchronisée. ID : ' . $invoice_id);
        $order->add_order_note('Abby réponse lignes : ' . wp_json_encode($response_lines));

    } catch (Exception $e) {
        $order->delete_meta_data('_abby_sync_in_progress');
        $order->save();

        $order->add_order_note('Erreur Abby : ' . $e->getMessage());
        error_log('SG Abby Sync - Erreur commande #' . $order_id . ' : ' . $e->getMessage());
    }
}

/**
 * API key getter.
 */
function sg_abby_sync_get_api_key() {
    return trim((string) get_option('sg_abby_sync_api_key', ''));
}

/**
 * API request wrapper.
 */
function sg_abby_sync_request($method, $endpoint, $body = null) {
    $api_key = sg_abby_sync_get_api_key();

    if (empty($api_key)) {
        throw new Exception('Clé API Abby manquante.');
    }

    $args = [
        'method'  => $method,
        'timeout' => 30,
        'headers' => [
            'Authorization' => 'Bearer ' . $api_key,
            'Accept'        => 'application/json',
        ],
    ];

    if ($body !== null) {
        $args['headers']['Content-Type'] = 'application/json';
        $args['body'] = wp_json_encode($body);
    }

    $response = wp_remote_request(SG_ABBY_SYNC_API_BASE . $endpoint, $args);

    if (is_wp_error($response)) {
        throw new Exception($response->get_error_message());
    }

    $code = wp_remote_retrieve_response_code($response);
    $raw  = wp_remote_retrieve_body($response);
    $data = json_decode($raw, true);

    if ($code < 200 || $code >= 300) {
        throw new Exception('API Abby HTTP ' . $code . ' : ' . $raw);
    }

    return is_array($data) ? $data : [];
}

/**
 * Find or create Abby contact.
 */
function sg_abby_sync_find_or_create_contact($order) {
    $email = strtolower(trim($order->get_billing_email()));
    $cache_key = 'sg_abby_contact_' . md5($email);

    $cached_contact_id = get_option($cache_key);

    if (!empty($cached_contact_id)) {
        return $cached_contact_id;
    }

    $contacts = sg_abby_sync_request(
        'GET',
        '/contacts?page=1&limit=50&search=' . rawurlencode($email)
    );

    if (!empty($contacts['docs']) && is_array($contacts['docs'])) {
        foreach ($contacts['docs'] as $contact) {
            $contact_id = $contact['id'] ?? null;
            $contact_emails = [];

            if (!empty($contact['email'])) {
                $contact_emails[] = strtolower(trim($contact['email']));
            }

            if (!empty($contact['emails']) && is_array($contact['emails'])) {
                foreach ($contact['emails'] as $contact_email) {
                    if (is_string($contact_email)) {
                        $contact_emails[] = strtolower(trim($contact_email));
                    } elseif (is_array($contact_email) && !empty($contact_email['email'])) {
                        $contact_emails[] = strtolower(trim($contact_email['email']));
                    }
                }
            }

            if ($contact_id && in_array($email, $contact_emails, true)) {
                update_option($cache_key, $contact_id);
                return $contact_id;
            }
        }

        if (count($contacts['docs']) === 1 && !empty($contacts['docs'][0]['id'])) {
            update_option($cache_key, $contacts['docs'][0]['id']);
            return $contacts['docs'][0]['id'];
        }
    }

    $payload = [
        'firstname' => $order->get_billing_first_name() ?: 'Client',
        'lastname'  => $order->get_billing_last_name() ?: 'WooCommerce',
        'phone'     => $order->get_billing_phone(),
        'emails'    => [$email],
        'notes'     => 'Créé automatiquement depuis WooCommerce commande #' . $order->get_id(),
    ];

    $created = sg_abby_sync_request('POST', '/contact', $payload);

    if (empty($created['id'])) {
        throw new Exception('Contact Abby créé sans ID retourné : ' . wp_json_encode($created));
    }

    update_option($cache_key, $created['id']);

    return $created['id'];
}

/**
 * Create draft invoice.
 */
function sg_abby_sync_create_draft_invoice($contact_id) {
    return sg_abby_sync_request('POST', '/v2/billing/invoice/' . rawurlencode($contact_id));
}

/**
 * Send invoice lines.
 */
function sg_abby_sync_update_invoice_lines($invoice_id, $order) {
    $lines = [];

    foreach ($order->get_items() as $item) {
        $product = $item->get_product();

        $quantity = max(1, (float) $item->get_quantity());
        $subtotal_ht = (float) $item->get_subtotal();
        $unit_price_ht = $quantity > 0 ? $subtotal_ht / $quantity : $subtotal_ht;

        $designation = $item->get_name();

        if ($product && $product->get_sku()) {
            $designation .= ' — SKU : ' . $product->get_sku();
        }

        $lines[] = [
            'isTaxIncluded' => false,
            'designation'   => $designation,
            'quantity'      => $quantity,
            'quantityUnit'  => 'unit',
            'unitPrice'     => (int) round($unit_price_ht * 100),
            'vatCode'       => sg_abby_sync_get_vat_code_from_order_item($item),
        ];
    }

    if ((float) $order->get_shipping_total() > 0) {
        $shipping_ht  = (float) $order->get_shipping_total();
        $shipping_tax = (float) $order->get_shipping_tax();

        $lines[] = [
            'isTaxIncluded' => false,
            'designation'   => 'Frais de livraison commande WooCommerce #' . $order->get_id(),
            'quantity'      => 1,
            'quantityUnit'  => 'unit',
            'unitPrice'     => (int) round($shipping_ht * 100),
            'vatCode'       => sg_abby_sync_get_vat_code_from_amounts($shipping_ht, $shipping_tax),
        ];
    }

    if (empty($lines)) {
        throw new Exception('Aucune ligne de commande à envoyer à Abby.');
    }

    return sg_abby_sync_request(
        'PATCH',
        '/v2/billing/' . rawurlencode($invoice_id) . '/lines',
        ['lines' => $lines]
    );
}

/**
 * VAT mapping.
 */
function sg_abby_sync_get_vat_code_from_order_item($item) {
    $subtotal_ht = (float) $item->get_subtotal();
    $tax_total   = (float) $item->get_subtotal_tax();

    return sg_abby_sync_get_vat_code_from_amounts($subtotal_ht, $tax_total);
}

function sg_abby_sync_get_vat_code_from_amounts($subtotal_ht, $tax_total) {
    if ($subtotal_ht <= 0 || $tax_total <= 0) {
        return 'FR_00HT';
    }

    $rate = round(($tax_total / $subtotal_ht) * 100, 1);

    if ($rate >= 19.5) return 'FR_2000';
    if ($rate >= 9.5)  return 'FR_1000';
    if ($rate >= 8.0)  return 'FR_850';
    if ($rate >= 5.0)  return 'FR_550';
    if ($rate >= 2.0)  return 'FR_210';

    return 'FR_00HT';
}
