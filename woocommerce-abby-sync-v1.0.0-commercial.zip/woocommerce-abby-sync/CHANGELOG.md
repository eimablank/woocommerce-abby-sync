# Changelog

## 1.0.0

- Initial public release.
- WooCommerce to Abby draft invoice synchronization.
- Abby contacts synchronization.
- WooCommerce VAT to Abby VAT code mapping.
- WooCommerce HPOS compatibility.
- Admin home tab.
- Admin settings tab.
- Abby API key test button.
- Duplicate prevention for customers and invoices.
